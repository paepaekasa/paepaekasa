package com.example.maize_yield_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
