#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=D:\education stufff\KASAWALA FOLDER\level 3 semester 6\flutter pro\flutter\src\flutter"
export "FLUTTER_APPLICATION_PATH=D:\education stufff\KASAWALA FOLDER\level 3 semester 6\vs mobile app\maize_yield_app"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
