import 'package:json_annotation/json_annotation.dart';

part 'prediction.g.dart';

@JsonSerializable()
class Prediction {
  final String id;
  final String userId;
  final String cropType;
  final double predictedYield;
  final String unit; // kg, tons, etc.
  final double confidence;
  final Map<String, dynamic> inputParameters;
  final List<String> recommendations;
  final DateTime createdAt;
  final DateTime? updatedAt;

  Prediction({
    required this.id,
    required this.userId,
    required this.cropType,
    required this.predictedYield,
    required this.unit,
    required this.confidence,
    required this.inputParameters,
    required this.recommendations,
    required this.createdAt,
    this.updatedAt,
  });

  factory Prediction.fromJson(Map<String, dynamic> json) => _$PredictionFromJson(json);
  Map<String, dynamic> toJson() => _$PredictionToJson(this);

  Prediction copyWith({
    String? id,
    String? userId,
    String? cropType,
    double? predictedYield,
    String? unit,
    double? confidence,
    Map<String, dynamic>? inputParameters,
    List<String>? recommendations,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Prediction(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      cropType: cropType ?? this.cropType,
      predictedYield: predictedYield ?? this.predictedYield,
      unit: unit ?? this.unit,
      confidence: confidence ?? this.confidence,
      inputParameters: inputParameters ?? this.inputParameters,
      recommendations: recommendations ?? this.recommendations,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

// Input parameters for prediction
class PredictionInput {
  final String cropType;
  final double soilPh;
  final double nitrogen;
  final double phosphorus;
  final double potassium;
  final double temperature;
  final double humidity;
  final double rainfall;
  final double irrigation;
  final String season;
  final double area; // in hectares

  PredictionInput({
    required this.cropType,
    required this.soilPh,
    required this.nitrogen,
    required this.phosphorus,
    required this.potassium,
    required this.temperature,
    required this.humidity,
    required this.rainfall,
    required this.irrigation,
    required this.season,
    required this.area,
  });

  Map<String, dynamic> toJson() {
    return {
      'cropType': cropType,
      'soilPh': soilPh,
      'nitrogen': nitrogen,
      'phosphorus': phosphorus,
      'potassium': potassium,
      'temperature': temperature,
      'humidity': humidity,
      'rainfall': rainfall,
      'irrigation': irrigation,
      'season': season,
      'area': area,
    };
  }
} 