import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:ulimi_smart/providers/auth_provider.dart';
import 'package:ulimi_smart/providers/prediction_provider.dart';
import 'package:ulimi_smart/screens/auth/login_screen.dart';
import 'package:ulimi_smart/screens/home/home_screen.dart';
import 'package:ulimi_smart/utils/app_colors.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    // Initialize providers
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final predictionProvider = Provider.of<PredictionProvider>(context, listen: false);

    // Wait for providers to initialize
    await Future.wait([
      authProvider.initialize(),
      predictionProvider.initialize(),
    ]);

    // Add a small delay for splash screen visibility
    await Future.delayed(const Duration(seconds: 2));

    // Navigate based on authentication status
    if (mounted) {
      if (authProvider.isAuthenticated) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const HomeScreen()),
        );
      } else {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const LoginScreen()),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppColors.primaryGradient,
        ),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // App Logo/Icon
              Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.agriculture,
                  size: 60,
                  color: AppColors.primary,
                ),
              )
                  .animate()
                  .fadeIn(duration: 600.ms)
                  .scale(begin: const Offset(0.5, 0.5), duration: 600.ms),

              const SizedBox(height: 40),

              // App Name
              Text(
                'Ulimi Smart',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 32,
                ),
              )
                  .animate()
                  .fadeIn(delay: 300.ms, duration: 600.ms)
                  .slideY(begin: 0.3, duration: 600.ms),

              const SizedBox(height: 8),

              // App Tagline
              Text(
                'Maize Yield Prediction',
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: Colors.white.withOpacity(0.9),
                  fontSize: 16,
                ),
              )
                  .animate()
                  .fadeIn(delay: 600.ms, duration: 600.ms)
                  .slideY(begin: 0.3, duration: 600.ms),

              const SizedBox(height: 80),

              // Loading Indicator
              SizedBox(
                width: 40,
                height: 40,
                child: CircularProgressIndicator(
                  strokeWidth: 3,
                  valueColor: AlwaysStoppedAnimation<Color>(
                    Colors.white.withOpacity(0.8),
                  ),
                ),
              )
                  .animate()
                  .fadeIn(delay: 900.ms, duration: 600.ms)
                  .then()
                  .shimmer(duration: 1500.ms, delay: 300.ms),

              const SizedBox(height: 20),

              // Loading Text
              Text(
                'Loading...',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Colors.white.withOpacity(0.7),
                ),
              )
                  .animate()
                  .fadeIn(delay: 1200.ms, duration: 600.ms),

              const Spacer(),

              // Footer Text
              Padding(
                padding: const EdgeInsets.all(20),
                child: Text(
                  'Empowering Maize Farmers with AI-Driven Insights',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Colors.white.withOpacity(0.6),
                    fontSize: 12,
                  ),
                ),
              )
                  .animate()
                  .fadeIn(delay: 1500.ms, duration: 600.ms),
            ],
          ),
        ),
      ),
    );
  }
} 